package com.starl.music;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;

public class MusicWidgetProvider extends AppWidgetProvider {
    @Override public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        for (int id : ids) {
            RemoteViews v = new RemoteViews(context.getPackageName(), R.layout.music_widget);
            android.content.SharedPreferences p = context.getSharedPreferences("starl_widget", Context.MODE_PRIVATE);
            v.setTextViewText(R.id.widget_title, p.getString("title", "Starl Music"));
            v.setTextViewText(R.id.widget_artist, p.getString("artist", "Open Starl to play music"));
            v.setTextViewText(R.id.widget_play, "playing".equals(p.getString("state", "paused")) ? "Ⅱ" : "▶");
            v.setOnClickPendingIntent(R.id.widget_open, pending(context, "OPEN", id));
            v.setOnClickPendingIntent(R.id.widget_prev, pending(context, "PREV", id));
            v.setOnClickPendingIntent(R.id.widget_play, pending(context, "PLAY", id));
            v.setOnClickPendingIntent(R.id.widget_next, pending(context, "NEXT", id));
            manager.updateAppWidget(id, v);
        }
    }
    private PendingIntent pending(Context c, String action, int id) {
        Intent i; if ("OPEN".equals(action)) { i = new Intent(c, MainActivity.class); i.setAction(Intent.ACTION_MAIN); i.addCategory(Intent.CATEGORY_LAUNCHER); i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP); }
        else { i = new Intent(c, MainActivity.class); i.setAction("com.starl.music.WIDGET_" + action); i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP); }
        return PendingIntent.getActivity(c, id * 10 + action.hashCode(), i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }
}
