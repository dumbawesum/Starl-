package com.starl.music;

import android.app.Activity;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    private static final int FILE_CHOOSER_REQUEST = 2026;
    private static final String ACTION_PLAY = "com.starl.music.WIDGET_PLAY";
    private static final String ACTION_NEXT = "com.starl.music.WIDGET_NEXT";
    private static final String ACTION_PREV = "com.starl.music.WIDGET_PREV";
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private WebChromeClient.FileChooserParams pendingFileChooserParams;
    private String pendingWidgetAction;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        webView.addJavascriptInterface(new WidgetBridge(), "StarlWidget");
        webView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                dispatchPendingWidgetAction();
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback; pendingFileChooserParams = params;
                try { Intent intent = params.createIntent(); startActivityForResult(intent, FILE_CHOOSER_REQUEST); return true; }
                catch (Exception e) { filePathCallback = null; pendingFileChooserParams = null; callback.onReceiveValue(null); return false; }
            }
        });
        setContentView(webView);
        webView.loadUrl("file:///android_asset/Starl4.html");
        handleWidgetIntent(getIntent());
    }

    @Override protected void onNewIntent(Intent intent) { super.onNewIntent(intent); setIntent(intent); handleWidgetIntent(intent); }
    private void handleWidgetIntent(Intent intent) { if (intent == null) return; String a = intent.getAction(); if (ACTION_PLAY.equals(a) || ACTION_NEXT.equals(a) || ACTION_PREV.equals(a)) { pendingWidgetAction = a; dispatchPendingWidgetAction(); } }
    private void dispatchPendingWidgetAction() {
        if (webView == null || pendingWidgetAction == null) return;
        final String action = pendingWidgetAction; pendingWidgetAction = null;
        webView.postDelayed(() -> {
            if (ACTION_PLAY.equals(action)) webView.evaluateJavascript("(function(){if(typeof T!=='undefined'&&T[cur]){playing=!playing;render();if(typeof auSync==='function')auSync();}})()", null);
            else if (ACTION_NEXT.equals(action)) webView.evaluateJavascript("(function(){if(typeof nextTrack==='function')nextTrack();})()", null);
            else if (ACTION_PREV.equals(action)) webView.evaluateJavascript("(function(){if(typeof prevTrack==='function')prevTrack();})()", null);
        }, 500);
    }

    private class WidgetBridge {
        @JavascriptInterface public void update(String title, String artist, String state, String color) {
            runOnUiThread(() -> {
                getSharedPreferences("starl_widget", MODE_PRIVATE).edit().putString("title", title).putString("artist", artist).putString("state", state).putString("color", color).apply();
                Intent refresh = new Intent(MainActivity.this, MusicWidgetProvider.class).setAction(AppWidgetManager.ACTION_APPWIDGET_UPDATE);
                int[] ids = AppWidgetManager.getInstance(MainActivity.this).getAppWidgetIds(new ComponentName(MainActivity.this, MusicWidgetProvider.class));
                refresh.putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids); sendBroadcast(refresh);
            });
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data); if (requestCode != FILE_CHOOSER_REQUEST) return;
        ValueCallback<Uri[]> callback = filePathCallback; WebChromeClient.FileChooserParams params = pendingFileChooserParams; filePathCallback = null; pendingFileChooserParams = null; if (callback == null) return;
        Uri[] results = null; if (resultCode == RESULT_OK && data != null) {
            try { if (params != null) results = params.parseResult(resultCode, data); } catch (Exception ignored) { results = null; }
            if (results == null) { if (data.getClipData() != null) { int count = data.getClipData().getItemCount(); results = new Uri[count]; for (int i=0;i<count;i++) results[i] = data.getClipData().getItemAt(i).getUri(); } else if (data.getData() != null) results = new Uri[]{data.getData()}; }
        } callback.onReceiveValue(results);
    }
    @Override public void onBackPressed() { if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed(); }
}
